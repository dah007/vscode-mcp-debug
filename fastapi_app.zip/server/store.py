# Simple in-memory store
debug_data = {
    "variables": {},
    "stack": [],
    "breakpoints": []
}
